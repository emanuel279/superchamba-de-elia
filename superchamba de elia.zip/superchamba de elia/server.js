const express = require('express');
const cors = require('cors'); // Importa cors
const axios = require('axios');
const app = express();
const PORT = 3000;

app.use(cors()); // Habilita CORS para todas las rutas
app.use(express.json());

app.post('/api/preguntar', async (req, res) => {
    const { question, collection } = req.body;

    try {
        const response = await axios.post('http://localhost:8000/buscar', {
            question: question,
            collection: collection
        });

        res.json({ respuesta: response.data.respuesta });
    } catch (error) {
        console.error('Error al consultar el microservicio:', error.message);
        res.status(500).json({ error: 'Error al consultar el microservicio.' });
    }
});

app.listen(PORT, () => {
    console.log(`Servidor Node.js corriendo en http://localhost:${PORT}`);
});


