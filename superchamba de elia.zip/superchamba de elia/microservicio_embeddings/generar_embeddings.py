from pymongo import MongoClient
from sentence_transformers import SentenceTransformer

# Conexión a MongoDB
client = MongoClient('mongodb+srv://jamaica:Dac9YCa5Y72jKrq@cluster0.5djxdgh.mongodb.net/PuriAire?retryWrites=true&w=majority')
db = client['PuriAire']

# Cargar el modelo de embeddings
model = SentenceTransformer('all-MiniLM-L6-v2')

# Lista de colecciones a procesar
colecciones = ['calidad_aire', 'contaminacion', 'recomendaciones']

for nombre_coleccion in colecciones:
    collection = db[nombre_coleccion]
    
    # Buscar solo las preguntas que no tienen embedding
    documentos_sin_embedding = list(collection.find({ 'embedding': { '$exists': False } }))

    print(f"🔍 Procesando colección: {nombre_coleccion}")
    print(f"Total de nuevas preguntas: {len(documentos_sin_embedding)}")

    for doc in documentos_sin_embedding:
        pregunta = doc.get('pregunta', '')
        if pregunta:
            # Generar embedding
            embedding = model.encode(pregunta).tolist()

            # Actualizar el documento con el embedding
            collection.update_one(
                { '_id': doc['_id'] },
                { '$set': { 'embedding': embedding } }
            )

            print(f"✅ Embedding guardado para pregunta: {pregunta}")

print("🎉 Proceso completado: Todos los nuevos embeddings han sido generados y guardados.")
