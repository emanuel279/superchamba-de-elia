from fastapi import FastAPI, Request
from pydantic import BaseModel
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from pymongo import MongoClient
import numpy as np

# Inicializar FastAPI
app = FastAPI()

# Cargar modelo de embeddings local
model = SentenceTransformer('all-MiniLM-L6-v2')

# Conectar con MongoDB
client = MongoClient('mongodb+srv://jamaica:Dac9YCa5Y72jKrq@cluster0.5djxdgh.mongodb.net/PuriAire?retryWrites=true&w=majority')
db = client['PuriAire']

# Modelo de entrada para las peticiones
class Query(BaseModel):
    question: str
    collection: str

@app.post("/buscar")
async def buscar_similitud(query: Query):
    user_embedding = model.encode([query.question])

    # Leer la colección seleccionada
    collection = db[query.collection]
    documentos = list(collection.find({}))

    if not documentos:
        return {"respuesta": "No encontré información."}

    # Preparar embeddings y respuestas
    base_embeddings = []
    respuestas = []
    for doc in documentos:
        if 'embedding' in doc:
            base_embeddings.append(doc['embedding'])
            respuestas.append(doc['respuesta'])

    if not base_embeddings:
        return {"respuesta": "No encontré embeddings en la colección."}

    # Calcular similitud
    similitudes = cosine_similarity(user_embedding, np.array(base_embeddings))
    idx_max = np.argmax(similitudes)
    mejor_respuesta = respuestas[idx_max]
    mejor_similitud = similitudes[0][idx_max]

    if mejor_similitud < 0.5:  # Puedes ajustar este umbral
        return {"respuesta": "No encontré una respuesta suficientemente cercana."}

    return {"respuesta": mejor_respuesta}
