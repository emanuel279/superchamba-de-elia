document.getElementById('sendBtn').addEventListener('click', async () => {
    const pregunta = document.getElementById('userInput').value;
    const coleccion = document.getElementById('collectionSelect').value;

    if (!pregunta.trim()) {
        document.getElementById('response').innerText = 'Por favor, escribe una pregunta.';
        return;
    }

    document.getElementById('response').innerText = 'Buscando respuesta...';

    try {
        const response = await fetch('http://localhost:3000/api/preguntar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ question: pregunta, collection: coleccion })
        });

        const data = await response.json();
        document.getElementById('response').innerText = data.respuesta;

    } catch (error) {
        console.error('Error al enviar la pregunta:', error);
        document.getElementById('response').innerText = 'Ocurrió un error al procesar tu solicitud.';
    }
});


